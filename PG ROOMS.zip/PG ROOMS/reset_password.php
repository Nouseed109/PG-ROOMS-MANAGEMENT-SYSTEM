<?php
$conn = mysqli_connect("localhost", "root", "", "pgrooms");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $query = "SELECT * FROM users WHERE password_reset_token = '$token'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        if (isset($_POST['submit'])) {
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $query = "UPDATE users SET password = '$new_password', password_reset_token = NULL WHERE password_reset_token = '$token'";
            mysqli_query($conn, $query);
            echo "<p style='color: green;'>Password reset successfully.</p>";
        } else {
            // Display password reset form
?>
            <style>
                body {
                    background-image: url('pgroom.jpeg');
                    background-size: cover;
                    background-position: center;
                    font-family: Arial, sans-serif;
                }
                
                .container {
                    width: 300px;
                    margin: 50px auto;
                    padding: 20px;
                    background-color:  rgba(19, 230, 237, 0.939);s
                    border: 1px solid #ddd;
                    border-radius: 10px;
                    box-shadow: 0 0 10px rgba(2, 0, 0, 0.1);
                }
                
                .form-group {
                    margin-bottom: 15px;
                }
                
                .form-group label {
                    display: block;
                    margin-bottom: 5px;
                }
                
                .form-group input {
                    width: 100%;
                    height: 40px;
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                }
                
                .btn {
                    width: 100%;
                    height: 40px;
                    padding: 10px;
                    background-color: #4CAF50;
                    color: #fff;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                }
                
                .btn:hover {
                    background-color: #3e8e41;
                }
            </style>
            <div class="container">
                <h2>Reset Password</h2>
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="new_password">New Password:</label>
                        <input type="password" id="new_password" name="new_password">
                    </div>
                    <button type="submit" name="submit" class="btn">Reset Password</button>
                </form>
            </div>
<?php
        }
    } else {
        echo "<p style='color: red;'>Invalid token.</p>";
    }
}

mysqli_close($conn);
?>
