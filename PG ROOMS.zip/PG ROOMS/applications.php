<?php 
// Start session
session_start();

// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get applications from database for the logged-in user
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM applications WHERE status = 'pending' AND user_id = '$user_id'";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pending Applications</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 80%;
            margin: 40px auto;
            border-collapse: collapse;
            background-color: #f2f2f2;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #ddd;
        }
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            color: #fff;
        }
        .approve-btn {
            background-color: #4CAF50;
        }
        .reject-btn {
            background-color: #f44336;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center;">Pending Applications</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>PG ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Message</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['pg_id']; ?></td>
                <td><?php echo $row['username']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['phone']; ?></td>
                <td><?php echo $row['message']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <a href="approve.php?id=<?php echo $row['id']; ?>" class="action-btn approve-btn">Approve</a>
                    <a href="reject.php?id=<?php echo $row['id']; ?>" class="action-btn reject-btn">Reject</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>