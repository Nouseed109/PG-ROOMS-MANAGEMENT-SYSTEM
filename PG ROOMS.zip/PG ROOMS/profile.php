<?php
// Start the session
session_start();

// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user details from the database
$username = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
             background-image: url("user.jpeg");
             background-size: cover;
             background-position: center;
             height: 100vh;
              margin: 0;
        }
        .profile-container {
            width: 60%;
            margin: 20px auto;
            padding: 20px;
            background-color:rgb(27, 171, 173);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(10, 92, 92, 0.1);
        }
        .profile-info {
            margin-bottom: 20px;
        }
        .profile-info label {
            font-weight: bold;
        }
    </style>
</head>
<body align="center">
    <div class="profile-container">
        <h1>User Profile</h1>
        <div class="profile-info">
            <label>Username:</label>
            <p><?php echo $user['username']; ?></p>
        </div>
        <div class="profile-info">
            <label>Email:</label>
            <p><?php echo $user['email']; ?></p>
        </div>
        <div class="profile-info">
            <label>Phone Number:</label>
            <p><?php echo $user['phone_number']; ?></p>
        </div>
        <div class="profile-info">
            <label>User Type:</label>
            <p><?php echo $user['usertype']; ?></p>
        </div>
    </div>
</body>
</html>