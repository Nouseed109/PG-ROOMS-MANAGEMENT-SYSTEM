<?php
echo "<p style='color:green;'>PG  updated Successfully</p>";
?>