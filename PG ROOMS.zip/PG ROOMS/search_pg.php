<?php 
// Connect to database 
$conn = mysqli_connect("localhost", "root", "", "pgrooms"); 
// Check connection 
if (!$conn) { 
    die("Connection failed: " . mysqli_connect_error()); 
} 
$user_id = $_SESSION['user_id'];
$sql = "SELECT pg.* FROM pg_details pg LEFT JOIN applications a ON pg.pg_id = a.pg_id AND a.user_id = '$user_id' AND a.status = 'approved' WHERE a.pg_id IS NULL";
if (isset($_POST['search'])) {
    $pg_type = $_POST['pg_type'];
    $sql .= " AND pg.pg_type = '$pg_type'";
}
$result = mysqli_query($conn, $sql);

function getAmenities($pg_id, $conn) { 
    $amenity_sql = "SELECT amenity_name FROM pg_amenities WHERE pg_id = '$pg_id'"; 
    $amenity_result = mysqli_query($conn, $amenity_sql); 
    $amenities = array(); 
    while ($amenity = mysqli_fetch_assoc($amenity_result)) { 
        $amenities[] = $amenity['amenity_name']; 
    } 
    return $amenities; 
} 

function getImages($pg_id, $conn) { 
    $image_sql = "SELECT image_url FROM pg_images WHERE pg_id = '$pg_id'"; 
    $image_result = mysqli_query($conn, $image_sql); 
    $images = array(); 
    while ($image = mysqli_fetch_assoc($image_result)) { 
        $images[] = $image['image_url']; 
    } 
    return $images; 
} 
?> 

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url("user.jpeg");
            background-size: cover;
            background-position: center;
            height: 100vh;
            margin: 0;
        }
        
        .pg-container {
            width: 50%;
            margin: 20px auto;
            padding: 20px;
            background-color: rgb(15, 166, 141);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .pg-info {
            margin-bottom: 20px;
        }
        
        .pg-info label {
            font-weight: bold;
        }
        
        form {
            width: 20%;
            margin: 10px auto;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        form label {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }
        
        form select {
            width: 100%;
            height: 40px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }
        
        form input[type="submit"] {
            width: 100%;
            height: 40px;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        form input[type="submit"]:hover {
            background-color: #3e8e41;
        }
        .pg-info img {
            width: 350px;
            height: 250px;
            margin: 10px;
            border-radius: 10px;
        }
        
        .apply-btn {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        
        .apply-btn:hover {
            background-color: #3e8e41;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center;">Search PGs</h1>
    <form action="" method="post">
        <label for="pg_type">Search PG by type:</label>
        <select name="pg_type" id="pg_type">
            <option value="boys">Boys</option>
            <option value="girls">Girls</option>
        </select>
        <input type="submit" name="search" value="Search">
    </form>
    <?php while ($pg = mysqli_fetch_assoc($result)) { ?>
        <div class="pg-container">
            <h2><?php echo $pg['pg_name']; ?></h2>
            <div class="pg-info">
                <label>Location:</label>
                <p><?php echo $pg['location']; ?></p>
            </div>
            <div class="pg-info">
                <label>Price:</label>
                <p><?php echo $pg['price']; ?></p>
            </div>
            <div class="pg-info">
                <label>Room Type:</label>
                <p><?php echo $pg['room_type']; ?></p>
            </div>
            <div class="pg-info">
                <label>Description:</label>
                <p><?php echo $pg['description']; ?></p>
            </div>
            <div class="pg-info">
                <label>Amenities:</label>
                <ul>
                    <?php foreach (getAmenities($pg['pg_id'], $conn) as $amenity) { ?>
                        <li><?php echo $amenity; ?></li>
                    <?php } ?>
                </ul>
            </div>
            <div class="pg-info">
                <label>Images:</label><br>
                <?php foreach (getImages($pg['pg_id'], $conn) as $image) { ?>
                    <img src="<?php echo $image; ?>" alt="PG Image">
                <?php } ?>
            </div>
            <div class="pg-info">
                <a href="send_applications.php?pg_id=<?php echo $pg['pg_id']; ?>" class="apply-btn">Apply Now</a>
            </div>
        </div>
    <?php } ?>
</body>
</html>
