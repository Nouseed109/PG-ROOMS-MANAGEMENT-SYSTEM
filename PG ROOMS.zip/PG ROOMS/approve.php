<?php
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get application ID
$id = $_GET['id'];

// Update application status to approved
$sql = "UPDATE applications SET status = 'approved' WHERE id = '$id'";
if (mysqli_query($conn, $sql)) {
    header("Location: owner.html");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>