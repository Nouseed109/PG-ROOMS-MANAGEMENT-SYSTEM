<?php 
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM applications WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if (isset($_POST['save_changes'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $message = $_POST['message'];

        $errors = array();

        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/@gmail\.com$/', $email)) {
            $errors[] = "Invalid email. Please enter a valid Gmail address.";
        }

        // Validate phone number
        if (!preg_match('/^\d{10}$/', $phone)) {
            $errors[] = "Invalid phone number. Please enter a 10-digit phone number.";
        }

        if (empty($errors)) {
            $sql = "UPDATE applications SET username = '$username', email = '$email', phone = '$phone', message = '$message' WHERE id = '$id'";
            if (mysqli_query($conn, $sql)) {
                header("Location: view_applications.php?email=$email");
            } else {
                echo "Error updating application: " . mysqli_error($conn);
            }
        } else {
            foreach ($errors as $error) {
                echo "<p style='color: red;'>$error</p>";
            }
        }
    }
?>

    <style>
        body {
            font-family: Arial, sans-serif;
             background: url('user.jpeg') no-repeat;
             background-size: cover;
             color: #333;
        }
        form {
            width: 20%;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(129, 80, 135, 0.9);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        form label {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }
        form input[type="text"], form input[type="email"] {
            width: 90%;
            height: 40px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }
        form textarea {
            width: 90%;
            height: 100px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }
        form input[type="submit"] {
            width: 90%;
            height: 40px;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        form input[type="submit"]:hover {
            background-color: #3e8e41;
        }
    </style>

    <h1 style="text-align: center;">Edit Application</h1>
    <form action="" method="post">
        <label>Name:</label>
        <input type="text" name="username" value="<?php echo $row['username']; ?>"><br><br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $row['email']; ?>"><br><br>
        <label>Phone:</label>
        <input type="text" name="phone" value="<?php echo $row['phone']; ?>"><br><br>
        <label>Message:</label>
        <textarea name="message"><?php echo $row['message']; ?></textarea><br><br>
        <input type="submit" name="save_changes" value="Edit Applications">
    </form>

<?php } else { ?>
    <p>Application not found.</p>
<?php } ?>