<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$conn = mysqli_connect("localhost", "root", "", "pgrooms");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];

    $query = "SELECT * FROM users WHERE username = '$username' AND email = '$email'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $token = bin2hex(random_bytes(32));
        $query = "UPDATE users SET password_reset_token = '$token' WHERE username = '$username'";
        mysqli_query($conn, $query);

        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'localhost';
            $mail->SMTPAuth = false;
            $mail->Port = 25;

            // Recipients
            $mail->setFrom('pgdeveloper@gmail.com', 'Pg_developer');
            $mail->addAddress($email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset';
            $link = "http://localhost/pgrooms/reset_password.php?token=$token";
            $mail->Body = "Paste this into your browser to reset your password: $link"; 

            $mail->send();
            echo 'Password reset link sent to your email.';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Invalid username or email.";
    }
}

mysqli_close($conn);
?>
