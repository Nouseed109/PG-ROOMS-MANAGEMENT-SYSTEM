<?php
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['pg_id'])) {
    $pg_id = $_GET['pg_id'];

    // Delete PG
    if (isset($_POST['delete'])) {
        $sql = "DELETE FROM pg_details WHERE pg_id = '$pg_id'";
        if (mysqli_query($conn, $sql)) {
            header("Location: delete.php"); // Redirect to a page after deletion
            exit;
        } else {
            echo "Error deleting PG: " . mysqli_error($conn);
        }
    }

    // Get PG details
    $sql = "SELECT * FROM pg_details WHERE pg_id = '$pg_id'";
    $result = mysqli_query($conn, $sql);
    $pg_details = mysqli_fetch_assoc($result);
?>

    <!-- Form to confirm deletion -->
    <h2>Delete PG</h2>
    <p>Are you sure you want to delete <?php echo $pg_details['pg_name']; ?>?</p>
    <form action="" method="post">
        <input type="submit" name="delete" value="Delete PG">
        <a href="pg_list.php">Cancel</a>
    </form>

<?php
}
?>