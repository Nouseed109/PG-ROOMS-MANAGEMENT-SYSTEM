<!DOCTYPE html>
<html>
<head>
    <title>Owner Dashboard</title>
    <link rel="stylesheet" href="styles1.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="#profile">Profile</a></li>
                <li><a href="#settings">Settings</a></li>
                <li><a href="#pg-details">PG Details</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="profile">
            <h2>Profile</h2>
            <p>Name: <span id="owner-name"></span></p>
            <p>Email: <span id="owner-email"></span></p>
        </section>
        <section id="settings">
            <h2>Settings</h2>
            <!-- settings form -->
        </section>
        <section id="pg-details">
            <h2>PG Details</h2>
            <button id="add-pg-btn">Add PG</button>
            <table id="pg-table">
                <thead>
                    <tr>
                        <th>PG Name</th>
                        <th>Location</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- pg details will be populated here -->
                </tbody>
            </table>
        </section>
        <!-- add pg form -->
        <div id="add-pg-form" style="display: none;">
            <h2>Add PG</h2>
            <form>
                <label for="pg-name">PG Name:</label>
                <input type="text" id="pg-name" name="pg_name"><br><br>
                <label for="location">Location:</label>
                <input type="text" id="location" name="location"><br><br>
                <label for="price">Price:</label>
                <input type="number" id="price" name="price"><br><br>
                <label for="amenities">Amenities:</label>
                <input type="text" id="amenities" name="amenities"><br><br>
                <label for="images">Images:</label>
                <input type="file" id="images" name="images"><br><br>
                <button type="submit">Add PG</button>
            </form>
        </div>
        <!-- edit pg form -->
        <div id="edit-pg-form" style="display: none;">
            <h2>Edit PG</h2>
            <form>
                <label for="edit-pg-name">PG Name:</label>
                <input type="text" id="edit-pg-name" name="pg_name"><br><br>
                <label for="edit-location">Location:</label>
                <input type="text" id="edit-location" name="location"><br><br>
                <label for="edit-price">Price:</label>
                <input type="number" id="edit-price" name="price"><br><br>
                <label for="edit-amenities">Amenities:</label>
                <input type="text" id="edit-amenities" name="amenities"><br><br>
                <label for="edit-images">Images:</label>
                <input type="file" id="edit-images" name="images"><br><br>
                <button type="submit">Update PG</button>
            </form>
        </div>
    </main>
    <script src="script.js"></script>
</body>
</html>
