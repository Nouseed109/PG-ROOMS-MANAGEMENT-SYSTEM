<?php
session_start();
header('location:user.php');
exit();
?>