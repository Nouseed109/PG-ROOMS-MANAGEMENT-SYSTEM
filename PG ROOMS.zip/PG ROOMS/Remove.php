<?php 
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['pg_id'])) {
    $pg_id = $_GET['pg_id'];

    // Delete PG
    if (isset($_POST['delete'])) {
        $sql = "DELETE FROM pg_details WHERE pg_id = '$pg_id'";
        if (mysqli_query($conn, $sql)) {
            header("Location: remove1.php"); // Redirect to a page after deletion
            exit;
        } else {
            echo "Error deleting PG: " . mysqli_error($conn);
        }
    }

    // Get PG details
    $sql = "SELECT * FROM pg_details WHERE pg_id = '$pg_id'";
    $result = mysqli_query($conn, $sql);
    $pg_details = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete PG</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image:url('owner.jpeg');
        }

        .delete-container {
            width: 50%;
            margin: 40px auto;
            padding: 20px;
            background-color:rgb(20, 134, 200);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .delete-container h2 {
            text-align: center;
        }

        .delete-btn {
            background-color: #d9534f;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .cancel-btn {
            background-color: #337ab7;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="delete-container">
        <h2>Delete PG</h2>
        <p>Are you sure you want to delete <?php echo $pg_details['pg_name']; ?>?</p>
        <form action="" method="post">
            <input type="submit" name="delete" value="Delete PG" class="delete-btn">
            <a href="remove1.php" class="cancel-btn">Cancel</a>
        </form>
    </div>
</body>
</html>

<?php } ?>