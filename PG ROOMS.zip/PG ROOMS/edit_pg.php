<?php 
// Start session
session_start();

// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['pg_id'])) {
    $pg_id = $_GET['pg_id'];
    $user_id = $_SESSION['user_id']; // Assuming you store user ID in session

    // Get PG details
    $sql = "SELECT * FROM pg_details WHERE pg_id = '$pg_id' AND user_id = '$user_id'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $pg_details = mysqli_fetch_assoc($result);

        // Update PG details
        if ($_SERVER["REQUEST_METHOD"]=="POST") {
            $pg_name = $_POST["pg_name"];
            $pg_type = $_POST['pg_type'];
            $location = $_POST["location"];
            $price = $_POST["price"];
            $room_type = $_POST['room_type'];
            $description = $_POST["description"];
            $sql = "UPDATE pg_details SET pg_name = '$pg_name', pg_type = '$pg_type', location = '$location', price = '$price', room_type = '$room_type', description = '$description' WHERE pg_id = '$pg_id' AND user_id = '$user_id'";
            if (mysqli_query($conn, $sql)) {
                header("Location:update.php");
                exit;
            } else {
                echo "Error updating PG: " . mysqli_error($conn);
            }
        }
    } else {
        echo "You do not have permission to edit this PG.";
        exit;
    }
} else {
    echo "PG ID not found.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit PG</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('owner.jpeg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .form-container {
            width: 40%;
            margin: 40px auto;
            padding: 20px;
            background-color: rgba(24, 209, 193, 0.8);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-container label {
            font-weight: bold;
        }

        .form-container input[type="text"], .form-container textarea {
            width: 90%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }

        .form-container input[type="submit"] {
            background-color: #4CAF50;
            color: #f0f0f0;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-container input[type="submit"]:hover {
            background-color: #3e8e41;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit PG</h2>
        <form action="" method="post">
            <label>PG Name:</label>
            <input type="text" name="pg_name" value="<?php echo $pg_details['pg_name']; ?>"><br><br>
            <label>PG Type:</label>
            <select name="pg_type">
                <option value="boys" <?php if($pg_details['pg_type'] == 'boys') echo 'selected'; ?>>Boys</option>
                <option value="girls" <?php if($pg_details['pg_type'] == 'girls') echo 'selected'; ?>>Girls</option>
            </select><br><br>
            <label>Location:</label>
            <input type="text" name="location" value="<?php echo $pg_details['location']; ?>"><br><br>
            <label>Price:</label>
            <input type="text" name="price" value="<?php echo $pg_details['price']; ?>"><br><br>
            <label>Room Type:</label>
            <input type="text" name="room_type" value="<?php echo $pg_details['room_type']; ?>"><br><br>
            <label>Description:</label>
            <textarea name="description"><?php echo $pg_details['description']; ?></textarea><br><br>
            <input type="submit" value="Update PG">
        </form>
    </div>
</body>
</html>

