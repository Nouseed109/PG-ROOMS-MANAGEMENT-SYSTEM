<?php
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['submit'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Check if username and password are entered
    if (empty($username)) {
        echo "<p style='color:red';>please enter username!!</p>";
        exit;
    }
    if (empty($password)) {
        echo "<p style='color:red';>Please enter password!!</p>";
        exit;
    }

    // Check if robot checkbox is checked
    if (!isset($_POST['not-robot'])) {
        echo "<p style='color: red ;'>Please verify you are not a robot!</p>";
        exit;
    }

    $conn = mysqli_connect("localhost", "root", "", "pgrooms");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['usertype'] = $row['usertype'];

            if (trim(strtolower($row['usertype'])) === 'user') {
                header("Location: user.html");
                exit();
            } elseif (trim(strtolower($row['usertype'])) === 'owner') {
                header("Location: owner.html");
                exit();
            } else {
                echo "<p style='color:red;'>Unknown usertype.</p>";
            }
        } else {
            echo "<p style='color:red;'>Invalid password!</p>";
        }
    } else {
        echo "<p style='color:red;'>Invalid username!</p>";
    }

    mysqli_close($conn);
}
?>

