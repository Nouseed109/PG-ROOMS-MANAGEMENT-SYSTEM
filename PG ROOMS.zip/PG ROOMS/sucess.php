<?php
echo "Application sent successfully!!";
?>