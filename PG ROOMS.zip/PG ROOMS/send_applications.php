<?php 
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get PG ID
$pg_id = $_GET['pg_id'];

// Get PG details
$sql = "SELECT user_id FROM pg_details WHERE pg_id = '$pg_id'";
$result = mysqli_query($conn, $sql);
$pg_details = mysqli_fetch_assoc($result);
$user_id = $pg_details['user_id'];

// Check if form is submitted
if (isset($_POST['submit'])) {
    $pg_id = $_POST['pg_id'];
    $name = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    // Validate name
    if (!preg_match("/^[A-Z][a-zA-Z]*$/", $name)) {
        echo "<p style='color:red;'>Name should start with a capital letter.</p>";
    } 
    // Validate email
    elseif (!preg_match("/^[a-zA-Z0-9._%+-]+@gmail\.com$/", $email)) {
        echo "<p style='color:red;'>Invalid email. Only @gmail.com emails are allowed.</p>";
    } 
    // Validate phone
    elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
        echo "<p style='color:red;'>Invalid phone number. Phone number should have 10 digits.</p>";
    } else {
        // Check if email or phone already exists
        $sql = "SELECT * FROM applications WHERE email = '$email' OR phone = '$phone' AND pg_id = '$pg_id'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            echo "<p style='color:red;'>Email or phone number already exists.</p>";
        } else {
            // Insert application into database
            $sql = "INSERT INTO applications (pg_id, user_id, username, email, phone, message, status) VALUES ('$pg_id', '$user_id', '$name', '$email', '$phone', '$message', 'pending')";
            if (mysqli_query($conn, $sql)) {
                echo "<p style='color:green;'>Application sent successfully</p>";
                exit();
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('user.jpeg');
            background-size: cover;
            background-position: center;
        }

        form {
            width: 20%;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(129, 80, 135, 0.9);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form label {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }

        form input[type="text"], form input[type="email"] {
            width: 100%;
            height: 40px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }

        form textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }

        form input[type="submit"] {
            width: 100%;
            height: 40px;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background-color: #3e8e41;
        }
    </style>
</head>
<body>
    <!-- Form to send application -->
    <form action="" method="post">
        <input type="hidden" name="pg_id" value="<?php echo $pg_id; ?>">
        <label>Name:</label>
        <input type="text" name="username" required>
        <small>First letter should be in Capital.</small><br><br>
        <label>Email:</label>
        <input type="email" name="email" required><br>
        <label>Phone:</label>
        <input type="text" name="phone" required><br>
        <label>Message:</label>
        <textarea name="message" required></textarea><br>
        <input type="submit" name="submit" value="Send Application">
    </form>
</body>
</html>