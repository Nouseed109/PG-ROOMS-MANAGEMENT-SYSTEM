<?php 
require_once 'db_connection.php';
error_reporting(1);

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $usertype = $_POST['usertype'];
    $created_at = date("Y-m-d H:i:s");
    $updated_at = date("Y-m-d H:i:s");

    // Validation
    $errors = array();

    if ($password !== $confirm_password) {
        $errors[] = "<p style='color:red';>Passwords do not match.</p>";
    }

    if (!preg_match("/^[a-zA-Z0-9._%+-]+@gmail\.com$/", $email)) {
        $errors[] = "<p style='color:red';>Email should be a valid Gmail address.</p>";
    }

    if (!preg_match("/^[0-9]{10}$/", $phone_number)) {
        $errors[] = "<p style='color:red';>Mobile number should have exactly 10 digits.</p>";
    }

    if (empty($errors)) {
        // Check if the username already exists
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<p style='color:red';>Username already exists. Please choose a different username.</p>";
        } else {
            // Check if the email already exists
            $sql = "SELECT * FROM users WHERE email = '$email'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                echo "<p style='color:red';>Email already exists. Please use a different email.</p>";
            } else {
                // Check if the mobile number already exists
                $sql = "SELECT * FROM users WHERE phone_number = '$phone_number'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    echo "<p style='color:red';>Mobile number already exists. Please use a different mobile number.</p>";
                } else {
                    // Insert the new user into the database
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $sql = "INSERT INTO users (username, password, email, phone_number, usertype, created_at, updated_at) VALUES ('$username', '$hashed_password', '$email', '$phone_number', '$usertype', '$created_at', '$updated_at')";
                    $result = $conn->query($sql);
                    if ($result) {
                        echo "<p style='color:green';>Registration successful </p>";
                    } else {
                        echo "<p style='color:red';>Error: </p>" . $conn->error;
                    }
                }
            }
        }
    } else {
        foreach ($errors as $error) {
            echo $error . "<br>";
        }
    }
}

$conn->close();
?>
