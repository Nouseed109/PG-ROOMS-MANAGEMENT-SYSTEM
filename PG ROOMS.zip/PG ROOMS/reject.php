<?php
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get application ID
$id = $_GET['id'];

// Update application status to rejected
$sql = "UPDATE applications SET status = 'rejected' WHERE id = '$id'";
mysqli_query($conn, $sql);
$sql= "DELETE FROM APPLICATIONS WHERE id= '$id' WHERE id='$id' AND status='rejected'";
mysqli_query($conn, $sql);
header("Location:owner.html");
?>

