<?php 
// Start session
session_start();

// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"]=="POST") {
    // Check if user is logged in
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        

        // Get form data
        $pg_name = $_POST["pg_name"];
        $pg_type = $_POST['pg_type'];
        $location = $_POST["location"];
        $price = $_POST["price"];
        $room_type = $_POST['room_type'];
        $description = $_POST["description"];
        $amenities = $_POST["amenities"];

        // Insert PG details into database
        $sql = "INSERT INTO pg_details (pg_name, pg_type, location, price, room_type, description, user_id) VALUES ('$pg_name', '$pg_type', '$location', '$price', '$room_type', '$description', '$user_id')";
        if (mysqli_query($conn, $sql)) {
            $pg_id = mysqli_insert_id($conn);

            // Insert amenities into database
            foreach ($amenities as $amenity) {
                $sql = "INSERT INTO pg_amenities (pg_id, amenity_name) VALUES ('$pg_id', '$amenity')";
                mysqli_query($conn, $sql);
            }

            // Handle image uploads
            if (isset($_FILES["images"])) {
                $images = $_FILES["images"];
                for ($i = 0; $i < count($images["tmp_name"]); $i++) {
                    $image_name = $images["name"][$i];
                    $image_url = "uploads/" . $image_name;
                    move_uploaded_file($images["tmp_name"][$i], $image_url);
                    $sql = "INSERT INTO pg_images (pg_id, image_url) VALUES ('$pg_id', '$image_url')";
                    mysqli_query($conn, $sql);
                }
            }

            echo " <p style='color:green';>PG added successfully!</p>";
        } else {
            echo "<p style='color:red';>Error adding PG: </p>" . mysqli_error($conn);
        }
    } else {
        echo "<p style='color:red';>You must be logged in to add a PG.</p>";
    }
}

mysqli_close($conn);
?>