<?php 
// Start session
session_start();

// Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM pg_details WHERE user_id = '$user_id'";
if (isset($_POST['search'])) {
    $pg_type = $_POST['pg_type'];
    $sql .= " AND pg_type = '$pg_type'";
}
$result = mysqli_query($conn, $sql);

function getAmenities($pg_id, $conn) {
    $amenity_sql = "SELECT amenity_name FROM pg_amenities WHERE pg_id = '$pg_id'";
    $amenity_result = mysqli_query($conn, $amenity_sql);
    $amenities = array();
    while ($amenity = mysqli_fetch_assoc($amenity_result)) {
        $amenities[] = $amenity['amenity_name'];
    }
    return $amenities;
}

function getImages($pg_id, $conn) {
    $image_sql = "SELECT image_url FROM pg_images WHERE pg_id = '$pg_id'";
    $image_result = mysqli_query($conn, $image_sql);
    $images = array();
    while ($image = mysqli_fetch_assoc($image_result)) {
        $images[] = $image['image_url'];
    }
    return $images;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Owner Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('owner.jpeg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .pg-container {
            width: 80%;
            margin: 40px auto;
            padding: 20px;
            background-color: rgba(69, 104, 121, 0.8);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .pg-info {
            margin-bottom: 20px;
        }

        .pg-info label {
            font-weight: bold;
        }

        .pg-info img {
            width: 200px;
            height: 150px;
            margin: 10px;
            border-radius: 10px;
        }

        .search-form {
            width: 40%;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(24, 209, 193, 0.8);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center;">My PGs</h1>
    <form class="search-form" action="" method="post">
        <label for="pg_type">Search PG by type:</label>
        <select name="pg_type" id="pg_type">
            <option value="boys">Boys</option>
            <option value="girls">Girls</option>
        </select>
        <input type="submit" name="search" value="Search">
    </form>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <div class="pg-container">
            <h2><?php echo $row['pg_name']; ?></h2>
            <div class="pg-info">
                <label>Location:</label>
                <p><?php echo $row['location']; ?></p>
            </div>
            <div class="pg-info">
                <label>Price:</label>
                <p><?php echo $row['price']; ?></p>
            </div>
            <div class="pg-info">
                <label>Room Type:</label>
                <p><?php echo $row['room_type']; ?></p>
            </div>
            <div class="pg-info">
                <label>Description:</label>
                <p><?php echo $row['description']; ?></p>
            </div>
            <div class="pg-info">
                <label>Amenities:</label>
                <ul>
                    <?php foreach (getAmenities($row['pg_id'], $conn) as $amenity) { ?>
                        <li><?php echo $amenity; ?></li>
                    <?php } ?>
                </ul>
            </div>
            <div class="pg-info">
                <label>Images:</label>
                <?php foreach (getImages($row['pg_id'], $conn) as $image) { ?>
                    <img src="<?php echo $image; ?>" alt="PG Image">
                <?php } ?>
            </div>
            <div class="pg-info">
            <a href="Remove.php?pg_id=<?php echo $row['pg_id']; ?>"><button style="background-color: #4CAF50; color: #fff; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">Delete PG</button></a>
            </div>
        </div>
    <?php } ?>
</body>
</html>
