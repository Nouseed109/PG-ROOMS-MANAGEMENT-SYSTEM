<style>
    body {
        font-family: Arial, sans-serif;
        background-image: url();
        background-size: cover;
        background-position: center;
    }
    
    form {
        width: 20%;
        margin: 20px auto;
        padding: 20px;
        background-color: rgba(255,255,255,1);
        border: 1px solid #ddd;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    
    form label {
        font-weight: bold;
        margin-bottom: 10px;
        display: block;
    }
    
    form input[type="email"] {
        width: 90%;
        height: 40px;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
    }
    
    form input[type="submit"] {
        width: 90%;
        height: 40px;
        padding: 10px;
        background-color: #4CAF50;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    
    form input[type="submit"]:hover {
        background-color: #3e8e41;
    }
    
    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
    }
    
    th, td {
        padding: 10px;
        text-align: left;
    }
    
    th {
        background-color:rgb(240, 240, 240);
    }
    .action-btn {
        padding: 5px 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        text-decoration: none;
        color: #fff;
    }
    .delete-btn {
        background-color: #f44336;
    }
    .edit-btn {
        background-color: #4CAF50;
    }
</style>

<?php // Connect to database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $sql = "SELECT * FROM applications WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
?>
    <!-- Display applications -->
    <h1 style="text-align: center;">My Applications</h1>
    <table border="1" bcolor="">
        <tr>
            <th>ID</th>
            <th>PG ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Message</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['pg_id']; ?></td>
                <td><?php echo $row['username']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['phone']; ?></td>
                <td><?php echo $row['message']; ?></td>
                <td>
                    <?php if($row['status'] == 'pending') { echo "<span style='color: orange;'>Pending</span>"; } elseif($row['status'] == 'approved') { echo "<span style='color: green;'>Approved</span>"; } else { echo "<span style='color: red;'>Rejected</span>"; } ?>
                </td>
                <td>
                    <?php if ($row['status'] == 'pending') { ?>
                        <a href="?delete_id=<?php echo $row['id']; ?>&email=<?php echo $email; ?>" class="action-btn delete-btn">Delete</a>
                        <a href="edit_application.php?id=<?php echo $row['id']; ?>" class="action-btn edit-btn">Edit</a>
                    <?php } else { ?>
                        Cannot Delete
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>
    <?php // Delete application
    if (isset($_GET['delete_id']) && isset($_POST['email'])) {
        $delete_id = $_GET['delete_id'];
        $sql = "DELETE FROM applications WHERE id = '$delete_id'";
        if (mysqli_query($conn, $sql)) {
            header("Location: ?email=$email");
        } else {
            echo "Error deleting application: " . mysqli_error($conn);
        }
    }
} else { ?>
    <form action="" method="post">
        <label>Email:</label>
        <input type="email" name="email" required>
        <input type="submit" value="View Applications">
    </form>
<?php } ?>

