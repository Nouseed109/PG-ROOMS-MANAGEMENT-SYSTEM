<?php
// Start the session
session_start();

// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "pgrooms");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user details from the database
$username = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Owner Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image:url('owner.jpeg');
        }
        .profile-container {
            width: 60%;
            margin: 20px auto;
            padding: 20px;
            background-color:rgba(24, 209, 193, 0.8);
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(10, 92, 92, 0.1);
        }
        .profile-info {
            margin-bottom: 20px;
        }
        .profile-info label {
            font-weight: bold;
        }
    </style>
</head>
<body align="center">
    <div class="profile-container">
        <h1>owner Profile</h1>
        <div class="profile-info">
            <label>Username:</label>
            <p><?php echo $user['username']; ?></p>
        </div>
        <div class="profile-info">
            <label>Email:</label>
            <p><?php echo $user['email']; ?></p>
        </div>
        <div class="profile-info">
            <label>Phone Number:</label>
            <p><?php echo $user['phone_number']; ?></p>
        </div>
        <div class="profile-info">
            <label>User Type:</label>
            <p><?php echo $user['usertype']; ?></p>
        </div>
    </div>
</body>
</html>